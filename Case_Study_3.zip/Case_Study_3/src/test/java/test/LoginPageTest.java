package test;


import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pages.Dashboardpage;
import pages.LoginPage;
import properties.BrowserProp;
import properties.ExcelDataProvider;

public class LoginPageTest {

	LoginPage loginPage;
	public static String webUrl = null;
	static WebDriver driver = null;

	// SetUp WebDriver
	@BeforeTest(alwaysRun = true)
	public static void setUpTest() {
		driver = WebDriverSetUp.setUpWebDriver();

	}

	// get the testData of LoginPage
	@DataProvider(name = "loginPageTestData")
	public Object[][] getLoginTestData() {

		Object data[][] = ExcelDataProvider.readLoginPageTestData("/src/test/resources/testdata.xlsx", "loginSheet");
		return data;
	}

	@Test(dataProvider = "loginPageTestData",priority = 0)
	public static void loginPageTest(String username, String password) {

		BrowserProp.getBrowserProperties();

		// load the webSite
		driver.get(webUrl);
		// Wait until page load
		//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//verify login page is successfully loaded
		LoginPage.checkLogin_Lbl();

		// Verify whether page title is correct
		Assert.assertEquals(driver.getTitle(), "OrangeHRM");
		System.out.println("Testing page title is: " + driver.getTitle());

		// Verify whether browser navigated to correct URL
		Assert.assertEquals(driver.getCurrentUrl(), webUrl);
		System.out.println("Testing page url is: " + driver.getCurrentUrl());

		// maximise the Browser
		driver.manage().window().maximize();
		
		//wait until Maximise browser
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);

		// Enter a UserName on UserName textBox
		LoginPage.settxt_UserName(username);

		// Enter a password on Password textBox
		LoginPage.settxt_Password(password);
		// Click the login button
		LoginPage.clickbtn_Login();

	}

	@Test(priority = 1)
	public static void navigateToAssignLeavePage() throws Exception {

		// click on the Assign Leave link
		Dashboardpage.checkLogin_Lbl();
		Dashboardpage.clicklnk_Assign_Leave();

		Thread.sleep(5000);
	}

	// close the driver & browser
	@AfterTest(timeOut = 60000)
	public static void tearDown() {

		// close the browser
		driver.close();
		driver.quit();
		System.out.println("Test Successfuly Completed");

	}

}
