package test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import pages.AssignLeavePage;
import pages.Dashboardpage;
import pages.LeaveListPage;
import pages.LoginPage;
import properties.BrowserProp;

public class WebDriverSetUp {

	public static String browserName = null;
	public static String chromeDriverPath = null;
	public static String geckoDriverPath = null;
	public static String ieDriverPath = null;

	static WebDriver driver;

	@SuppressWarnings("deprecation")
	public static WebDriver setUpWebDriver() {

		BrowserProp.getBrowserProperties();

		// get the path of project location
		String projLocation = System.getProperty("user.dir");
		// setup ChromeDriver
		if (browserName.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", projLocation + chromeDriverPath);
			driver = new ChromeDriver();

		}
		// setup Fire_fox driver
		else if (browserName.equalsIgnoreCase("firefox")) {
			System.setProperty("webdriver.gecko.driver", projLocation + geckoDriverPath);
			driver = new FirefoxDriver();
		}
		// setup IE driver
		else if (browserName.equalsIgnoreCase("ie")) {
			
			//Set Up DesiredCapabilities for handling browser protection mode
			DesiredCapabilities caps = new DesiredCapabilities();
			caps.setCapability("ignoreProtectedModeSettings", true);
			caps.setBrowserName("internet explorer");
			
			System.setProperty("webdriver.ie.driver", projLocation + ieDriverPath);
			driver = new InternetExplorerDriver(caps);
		}

		// Call a Constructor of LoginPage class
		new LoginPage(driver);
		// Call a Constructor of Dashboardpage class
		new Dashboardpage(driver);
		// Call a Constructor of AssignLeavePage class
		new AssignLeavePage(driver);
		// Call a Constructor of LeaveListPage class
		new LeaveListPage(driver);
		return driver;
	}
}
