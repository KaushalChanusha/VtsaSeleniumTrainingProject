package test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import pages.AssignLeavePage;
import pages.Dashboardpage;
import pages.LeaveListPage;
import pages.LoginPage;
import properties.BrowserProp;
import properties.ExcelDataProvider;

public class LeaveListPageTest {

	public static String webUrl = null;
	static WebDriver driver = null;
	static ExtentHtmlReporter htmlReporter = null;
	static ExtentReports extent = null;

	// Sent up extent reporter
	@BeforeSuite
	public void setUp() {
		// start reporters
		htmlReporter = new ExtentHtmlReporter("extent.html");

		// create ExtentReports and attach reporter(s)
		extent = new ExtentReports();
		extent.attachReporter(htmlReporter);

	}

	// Set up webDriver
	@BeforeTest
	public static void setUpTest() {
		driver = WebDriverSetUp.setUpWebDriver();

	}

	// get the testData of LoginPage
	@DataProvider(name = "loginPageTestData")
	public Object[][] getLoginTestData() {

		Object data[][] = ExcelDataProvider.readLoginPageTestData("/src/test/resources/testdata.xlsx", "loginSheet");
		return data;
	}

	// Test the login page functionality
	@Test(dataProvider = "loginPageTestData", timeOut = 50000, priority = 1)
	public static void loadLoginPage(String username, String password) {

		// creates a toggle for the given test, adds all log events under it
		ExtentTest testlp = extent.createTest("This is for validate to user login functionality");
		BrowserProp.getBrowserProperties();

		// log(Status, details)
		testlp.log(Status.INFO, "Starting Test Case of User Login fuctionality");

		// load the webSite
		driver.get(webUrl);
		testlp.pass("Browser is navigate to OrangeHRM successfuly");

		// Wait until page load
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		// Verify whether page title is correct
		Assert.assertEquals(driver.getTitle(), "OrangeHRM");
		System.out.println("Testing page title is: " + driver.getTitle());

		// Verify whether browser navigated to correct URL
		Assert.assertEquals(driver.getCurrentUrl(), webUrl);
		System.out.println("Testing page url is: " + driver.getCurrentUrl());

		// maximise the Browser
		driver.manage().window().maximize();

		// wait until Maximise browser
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);

		// Enter userName
		LoginPage.settxt_UserName(username);
		testlp.pass("Enter the Username in the textbox");

		// Enter Password
		LoginPage.settxt_Password(password);
		testlp.pass("Enter the Password in the textbox");

		// click on login button
		LoginPage.clickbtn_Login();
		testlp.pass("Pressed the Login button");

		// click on the Assign Leave link
		Dashboardpage.checkLogin_Lbl();
		testlp.info("Dashboard page is loaded");
		testlp.pass("Dashboard label successfuly found");

		Dashboardpage.clicklnk_Assign_Leave();
		testlp.pass("Click the Assign Leave page Link");

	}

	@Test(priority = 2)
	public static void AssignLeavePageTest() throws Exception {

		ExcelDataProvider.getAssignLeavePageTestData("/src/test/resources/testdata.xlsx", "assignLeaveSheet");
		ExtentTest testalp = extent.createTest("This is for validate to Leave Assigning fuctionality");

		/********** Testing Assign Leave Page start from here *****************/
		// log(Status, details)
		testalp.log(Status.INFO, "Starting Test Case of Assign Leave functionality");
		
		try {
			// Check whether assign page is loaded
			AssignLeavePage.checkAssignLeave_Lbl();
			testalp.info("Assign Leave page is loaded");
			testalp.pass("Assign Leave page label successfuly found");

		} catch (Exception e) {
			testalp.fail("Assign Leave Page loading error");
			System.out.println(e.getMessage());
			e.printStackTrace();
		}

		// Set employee name
		AssignLeavePage.setEmployeeName_txt(ExcelDataProvider.emp_Name);
		testalp.pass("Enter the employee name in the textbox");

		// Select leave type
		AssignLeavePage.selectLeaveType_dpDown(ExcelDataProvider.leaveindex);
		testalp.pass("Select the leave type from the dropdown");

		// wait until display available leave balance
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		try {
			// open leave balance details window
			AssignLeavePage.clickLeaveBalance_lnk();
			testalp.pass("Click the view leave balance link");

			Thread.sleep(3000);
			// Click on okay button of leave balance detail window
			AssignLeavePage.clickLeaveBalance_btn();
			testalp.pass("Click okay button of leave balance window");
		} catch (Exception e) {
			testalp.fail("View balance details window is not displayed");
			System.out.println(e.getMessage());
			e.printStackTrace();
		}

		// wait until close the leave balance details window
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		// Pick the leave start date
		AssignLeavePage.setFromDate_dtPicker(ExcelDataProvider.fromDate);
		testalp.pass("Select the leave start date from date picker");

		// wait until select the date
		// driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		// Pick the leave end date
		AssignLeavePage.setToDate_dtPicker(ExcelDataProvider.toDate);
		testalp.pass("Select the leave end date from date picker");

		// wait until select the date
		// driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		// Select the duration type
		AssignLeavePage.selectDuration_dpDown();
		testalp.pass("Select the duration type from dropdown");

		// driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		// set reason for the leave
		AssignLeavePage.setComment_textArea(ExcelDataProvider.comment);
		testalp.pass("Add the comment in the textarea");

		// Submit the Assign Leave form
		AssignLeavePage.clickAssignLeave_btn();
		testalp.pass("Pressed the leave assign button");

		Thread.sleep(5000);

	}

	@Test(priority = 3)
	public static void leaveListPageTest() throws Exception {

		ExcelDataProvider.getLeaveListPageTestData("/src/test/resources/testdata.xlsx", "leaveListSheet");
		ExtentTest testslp = extent.createTest("This is for validate to Leave searching fuctionality");

		testslp.log(Status.INFO, "Starting Test Case of Search Leave functionality");
		// Navigate to Leave List page
		AssignLeavePage.gotoLeaveListPage();
		testslp.info("Leave list page is loaded");
		testslp.pass("Leave list page loaded successfuly");

		// Set start date of search
		LeaveListPage.setLeaveFromDt_dtP();
		testslp.pass("Select the start date from date picker");

		// Set start end of search
		LeaveListPage.setLeaveToDt_dtP();
		testslp.pass("Select the end date from date picker");

		// Thread.sleep(2000);

		// unchecked pending approval check box
		LeaveListPage.selectLeaveStsPAprv_chkBx();

		// Select Leave status type
		if (ExcelDataProvider.leaveSts.equalsIgnoreCase("Rejected")) {
			LeaveListPage.selectLeaveStsRej_chkBx();
			testslp.pass("Select the rejected status from checklistr");
		}

		else if (ExcelDataProvider.leaveSts.equalsIgnoreCase("Cancelled")) {
			LeaveListPage.selectLeaveStsCncl_chkBx();
			testslp.pass("Select the Cancelled status from checklistr");
		} else if (ExcelDataProvider.leaveSts.equalsIgnoreCase("Pending Approval")) {
			LeaveListPage.selectLeaveStsPAprv_chkBx();
			testslp.pass("Select the Pending Approval status from checklistr");
		} else if (ExcelDataProvider.leaveSts.equalsIgnoreCase("Scheduled")) {
			LeaveListPage.selectLeaveStsSchdl_chkBx();
			testslp.pass("Select the Scheduled status from checklistr");
		} else if (ExcelDataProvider.leaveSts.equalsIgnoreCase("Taken")) {
			LeaveListPage.selectLeaveStsTkn_chkBx();
			testslp.pass("Select the Taken status from checklistr");
		} else if (ExcelDataProvider.leaveSts.equalsIgnoreCase("All")) {
			try {
				LeaveListPage.selectLeaveStsAll_chkBx();
				testslp.pass("Select the All status from checklistr");
			} catch (Exception e) {
				testslp.fail("Leave status All selection error");
				e.printStackTrace();
				System.out.println(e.getMessage());
				e.getCause();
			}
		}

		// Set employee name
		LeaveListPage.setEmpName_txt(ExcelDataProvider.schEmpName);
		testslp.pass("Enter the employee name in the textbox");

		// select leave Sub Unit
		LeaveListPage.selectSubUnit_dpDown(ExcelDataProvider.subUnitIndex);
		testslp.pass("Select sub unit from the dropdown");

		// select the past employee status
		if (ExcelDataProvider.passEmp.equalsIgnoreCase("Yes")) {
			LeaveListPage.selectPastEmp_chkBx();
			testslp.pass("check the past employee checkbox");
		}

		// click on leave search button
		LeaveListPage.clickSearchLeave_btn();
		testslp.pass("Pressed the leave search button");

		Thread.sleep(3000);

	}

	@Test(priority = 4)
	public static void removeLeaveTest() throws Exception {

		ExtentTest testrlp = extent.createTest("This is for validate to Leave removing fuctionality");
		testrlp.log(Status.INFO, "Starting Test Case of Remove Leave functionality");

		try {
			LeaveListPage.getNoRcdFound_lbl();
			Assert.assertTrue(LeaveListPage.elbl_No_Record.isDisplayed());
			System.out.println("No Leave Reacords for " + ExcelDataProvider.schEmpName);
			testrlp.pass("No leave records found");

		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			// Select cancel status for the leave
			LeaveListPage.selectLeaveAction_dpDown();
			testrlp.pass("select the leave cancel staus from dropdowmn");

			// click on save button
			LeaveListPage.clickLeaveActSave_btn();
			testrlp.pass("Pressed the action save button");
		}
		testrlp.info("Test Successfuly Completed");
		Thread.sleep(5000);

	}
	
	// close the driver & browser
		@AfterTest(timeOut = 60000)
		public static void tearDown() {

			// close the browser
			driver.close();
			driver.quit();
			System.out.println("Test Successfuly Completed");

		}

	@AfterSuite
	public void tearDownExtentReports() {

		// calling flush writes everything to the log file
		extent.flush();
	}
}
