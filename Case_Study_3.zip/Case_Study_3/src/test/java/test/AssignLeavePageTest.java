package test;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pages.AssignLeavePage;
import pages.Dashboardpage;
import pages.LoginPage;
import properties.BrowserProp;
import properties.ExcelDataProvider;

public class AssignLeavePageTest {

	public static String webUrl = null;
	static WebDriver driver = null;

	// Set up webDriver
	@BeforeTest
	public static void setUpTest() {
		driver = WebDriverSetUp.setUpWebDriver();

	}

	// get the testData of LoginPage
	@DataProvider(name = "loginPageTestData")
	public Object[][] getLoginTestData() {

		Object data[][] = ExcelDataProvider.readLoginPageTestData("/src/test/resources/testdata.xlsx", "loginSheet");
		return data;
	}

	@Test(dataProvider = "loginPageTestData", timeOut = 50000, priority = 1)
	public static void loadLoginPage(String username, String password) {

		BrowserProp.getBrowserProperties();

		// load the webSite
		driver.get(webUrl);

		// Wait until page load
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		// Verify whether page title is correct
		Assert.assertEquals(driver.getTitle(), "OrangeHRM");
		System.out.println("Testing page title is: " + driver.getTitle());

		// Verify whether browser navigated to correct URL
		Assert.assertEquals(driver.getCurrentUrl(), webUrl);
		System.out.println("Testing page url is: " + driver.getCurrentUrl());

		// maximise the Browser
		driver.manage().window().maximize();

		// wait until Maximise browser
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);

		// Enter userName
		LoginPage.settxt_UserName(username);
		// Enter Password
		LoginPage.settxt_Password(password);
		// click on login button
		LoginPage.clickbtn_Login();

		// click on the Assign Leave link
		Dashboardpage.checkLogin_Lbl();
		Dashboardpage.clicklnk_Assign_Leave();

	}

	@Test(priority = 2)
	public static void testAssignLeavePage() throws Exception {

		ExcelDataProvider.getAssignLeavePageTestData("/src/test/resources/testdata.xlsx", "assignLeaveSheet");

		/********** Testing Assign Leave Page start from here *****************/
		// Check whether assign page is loaded
		AssignLeavePage.checkAssignLeave_Lbl();

		// Set employee name
		AssignLeavePage.setEmployeeName_txt(ExcelDataProvider.emp_Name);

		// Select leave type
		AssignLeavePage.selectLeaveType_dpDown(ExcelDataProvider.leaveindex);

		// open leave balance details window
		AssignLeavePage.clickLeaveBalance_lnk();

		// wait until opening the leave balance detail window
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		Thread.sleep(5000);
		// Click on okay button of leave balance detail window
		AssignLeavePage.clickLeaveBalance_btn();

		// wait until close the leave balance details window
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		// Pick the leave start date
		AssignLeavePage.setFromDate_dtPicker(ExcelDataProvider.fromDate);

		// wait until select the date
		//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		// Pick the leave end date
		AssignLeavePage.setToDate_dtPicker(ExcelDataProvider.toDate);

		// wait until select the date
		//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		// Select the duration type
		AssignLeavePage.selectDuration_dpDown();

		//driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		// set reason for the leave
		AssignLeavePage.setComment_textArea(ExcelDataProvider.comment);

		// Submit the Assign Leave form
		AssignLeavePage.clickAssignLeave_btn();

		Thread.sleep(5000);

	}

	@Test(priority = 3)
	public static void testAssignLeavePage2() throws Exception {

		ExcelDataProvider.getAssignLeavePageTestData2("/src/test/resources/testdata.xlsx", "assignLeaveSheet");

		/********** Testing Assign Leave Page start from here *****************/
		// Check whether assign page is loaded
		AssignLeavePage.checkAssignLeave_Lbl();

		// Set employee name
		AssignLeavePage.setEmployeeName_txt(ExcelDataProvider.emp_Name);

		// Select leave type
		AssignLeavePage.selectLeaveType_dpDown(ExcelDataProvider.leaveindex);

		try {
			// open leave balance details window
			AssignLeavePage.clickLeaveBalance_lnk();

		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		
		Thread.sleep(5000);
		
		// Click on okay button of leave balance detail window
		AssignLeavePage.clickLeaveBalance_btn();

		// wait until close the leave balance details window
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		// Pick the leave start date
		AssignLeavePage.setFromDate_dtPicker(ExcelDataProvider.fromDate);

		// wait until select the date
		//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		// Pick the leave end date
		AssignLeavePage.setToDate_dtPicker(ExcelDataProvider.toDate);

		// wait until select the date
		//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		// Select the duration type
		AssignLeavePage.selectDuration_dpDown();

		//driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		// set reason for the leave
		AssignLeavePage.setComment_textArea(ExcelDataProvider.comment);

		// Submit the Assign Leave form
		AssignLeavePage.clickAssignLeave_btn();

		Thread.sleep(5000);

	}

	// close the driver & browser
	@AfterTest(timeOut = 60000)
	public static void tearDown() {

		// close the browser
		driver.close();
		driver.quit();
		System.out.println("Test Successfuly Completed");

	}
}
