package pages;

import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.testng.Assert;

import properties.DashboardPageProp;

public class Dashboardpage {

	// Create object of WebDriver interface
	static WebDriver driver = null;

	// Define WebElement variables of Login page
	static WebElement elbl_Dashboard;
	static WebElement elink_Assign_Leave;

	// Create constructor of a class
	public Dashboardpage(WebDriver webDriver) {
		driver = webDriver;
	}

	// Find the DashBoard label WebElement
	public static void checkLogin_Lbl() {
		
		//wait until page load
		@SuppressWarnings("deprecation")
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(30, TimeUnit.SECONDS)
				.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(DashboardPageProp.getlblDashboard())));

		elbl_Dashboard = driver.findElement(By.xpath(DashboardPageProp.getlblDashboard()));
		Assert.assertTrue(elbl_Dashboard.isDisplayed());
		Assert.assertEquals(elbl_Dashboard.getText(), "Dashboard");
		System.out.println("Dashboad Page successfuly loaded");
		
	}

	// Find the DashBoard label WebElement
	public static void clicklnk_Assign_Leave() {

		elink_Assign_Leave = driver.findElement(By.xpath(DashboardPageProp.getlnkAssignLeave()));
		Assert.assertTrue(elink_Assign_Leave.isEnabled());
		elink_Assign_Leave.click();

	}

}
