package pages;

import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.testng.Assert;

import properties.LoginPageProp;

public class LoginPage {

	// Create object of WebDriver interface
	static WebDriver driver = null;

	// Define WebElement variables of Login page
	static WebElement elbl_Login;
	static WebElement etxt_UserName;
	static WebElement etxtPassword;
	static WebElement ebtnLogin;

	// Create constructor of a class
	public LoginPage(WebDriver webDriver) {

		driver = webDriver;
	}

	// Find the Login page label WebElement
	public static void checkLogin_Lbl() {

		elbl_Login = driver.findElement(By.id(LoginPageProp.getlblLoginPage()));

		// Wait until page load
		@SuppressWarnings("deprecation")
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(30, TimeUnit.SECONDS)
				.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(LoginPageProp.getlblLoginPage())));

		Assert.assertTrue(elbl_Login.isDisplayed());
		Assert.assertEquals(elbl_Login.getText(), "LOGIN Panel");
		System.out.println("Login Page Successfuly Loaded");

	}

	// Find the UserName TextBox WebElement
	public static void settxt_UserName(String username) {

		etxt_UserName = driver.findElement(By.id(LoginPageProp.gettxtUserName()));
		etxt_UserName.sendKeys(username);
	}

	// Find the Password TextBox WebElement
	public static void settxt_Password(String password) {

		etxtPassword = driver.findElement(By.id(LoginPageProp.gettxtPassword()));
		etxtPassword.sendKeys(password);
	}

	// Find the Login button WebElement
	public static void clickbtn_Login() {

		ebtnLogin = driver.findElement(By.id(LoginPageProp.getbtnLogin()));
		ebtnLogin.sendKeys(Keys.RETURN);
	}

}
