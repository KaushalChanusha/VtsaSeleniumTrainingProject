package pages;

import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;

import properties.LeaveListPageProp;

public class LeaveListPage {

	// Create object of WebDriver interface
	static WebDriver driver = null;

	static WebElement edtPicker_From_dt;
	static WebElement edtPicker_To_dt;
	static WebElement echkBx_Leave_Sts_All;
	static WebElement echkBx_Leave_Sts_Rej;
	static WebElement echkBx_Leave_Sts_Cncl;
	static WebElement echkBx_Leave_Sts_PAprv;
	static WebElement echkBx_Leave_Sts_Schdl;
	static WebElement echkBx_Leave_Sts_Tkn;
	static WebElement etxt_Emp_Name;
	static WebElement edpDown_Sub_Unit;
	static WebElement echkBox_Past_Emp;
	static WebElement ebtn_Leave_Search;
	public static WebElement elbl_No_Record;
	static WebElement edpDown_Leave_Action;
	static WebElement ebtn_Leave_Act_Save;
	static WebElement elbl_Leave_Cur_Status;

	// Create constructor of a class
	public LeaveListPage(WebDriver webDriver) {
		driver = webDriver;
	}

	// Set the start date for viewing leave list
	public static void setLeaveFromDt_dtP() {
		
		//wait until leave list page load
		@SuppressWarnings("deprecation")
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(30, TimeUnit.SECONDS)
				.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(LeaveListPageProp.getdtPickerFromDt())));

		edtPicker_From_dt = driver.findElement(By.xpath(LeaveListPageProp.getdtPickerFromDt()));
		edtPicker_From_dt.clear();
		edtPicker_From_dt.sendKeys("2018-01-01");
		edtPicker_From_dt.click();
	}

	// Set the end date for viewing leave list
	public static void setLeaveToDt_dtP() {

		edtPicker_To_dt = driver.findElement(By.xpath(LeaveListPageProp.getdtPickerToDt()));
		edtPicker_To_dt.clear();
		edtPicker_To_dt.sendKeys("2019-01-01");
		edtPicker_To_dt.click();
	}

	// Select the leave status All
	public static void selectLeaveStsAll_chkBx() {

		echkBx_Leave_Sts_All = driver.findElement(By.xpath(LeaveListPageProp.getchkBxAllLeaveSts()));
		echkBx_Leave_Sts_All.click();

	}

	// Select the leave status Reject
	public static void selectLeaveStsRej_chkBx() {

		echkBx_Leave_Sts_Rej = driver.findElement(By.xpath(LeaveListPageProp.getchkBxRejLeaveSts()));
		echkBx_Leave_Sts_Rej.click();

	}

	// Select the leave status Cancel
	public static void selectLeaveStsCncl_chkBx() {

		echkBx_Leave_Sts_Cncl = driver.findElement(By.xpath(LeaveListPageProp.getchkBxCnclLeaveSts()));
		echkBx_Leave_Sts_Cncl.click();

	}

	// Select the leave status Pending Approval
	public static void selectLeaveStsPAprv_chkBx() {

		//wait 5 seconds using implicit wait until end date is selected 
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		//WebDriverWait wait = new WebDriverWait(driver, 3);
		//wait.until(ExpectedConditions.elementToBeSelected(edtPicker_To_dt));
		
		echkBx_Leave_Sts_PAprv = driver.findElement(By.xpath(LeaveListPageProp.getchkBxPAprvLeaveSts()));
		echkBx_Leave_Sts_PAprv.click();

	}

	// Select the leave status Scheduled
	public static void selectLeaveStsSchdl_chkBx() {

		echkBx_Leave_Sts_Schdl = driver.findElement(By.xpath(LeaveListPageProp.getchkBxSchdlLeaveSts()));
		echkBx_Leave_Sts_Schdl.click();

	}

	// Select the leave status Scheduled
	public static void selectLeaveStsTkn_chkBx() {

		echkBx_Leave_Sts_Tkn = driver.findElement(By.xpath(LeaveListPageProp.getchkBxTknLeaveSts()));
		echkBx_Leave_Sts_Tkn.click();

	}

	// Set employee name
	public static void setEmpName_txt(String empName) {

		etxt_Emp_Name = driver.findElement(By.xpath(LeaveListPageProp.gettxtEmpName()));
		etxt_Emp_Name.clear();
		etxt_Emp_Name.sendKeys(empName);

	}

	// Select sub unit of the leave
	public static void selectSubUnit_dpDown(int subUnitIndex) {

		edpDown_Sub_Unit = driver.findElement(By.xpath(LeaveListPageProp.getdpDownSubUnit()));
		Select subUnit = new Select(edpDown_Sub_Unit);
		subUnit.selectByIndex(subUnitIndex);

	}

	// Select past employee check box
	public static void selectPastEmp_chkBx() {

		echkBox_Past_Emp = driver.findElement(By.xpath(LeaveListPageProp.getchkBxPastEmp()));
		echkBox_Past_Emp.click();

	}

	// Click search button of Leave list
	public static void clickSearchLeave_btn() {

		ebtn_Leave_Search = driver.findElement(By.xpath(LeaveListPageProp.getbtnSearchLeave()));
		ebtn_Leave_Search.sendKeys(Keys.RETURN);

	}

	// get the text of no record found label
	public static void getNoRcdFound_lbl() {

		elbl_No_Record = driver.findElement(By.xpath(LeaveListPageProp.getlblNoSearchRecords()));
		//System.out.println(elbl_No_Record.getText());

	}

	// select the action for the leave
	public static void selectLeaveAction_dpDown() {

		edpDown_Leave_Action = driver.findElement(By.xpath(LeaveListPageProp.getdpDownLeaveAction()));
		Select leaveAction = new Select(edpDown_Leave_Action);
		leaveAction.selectByIndex(1);

	}

	// click on save leave action button
	public static void clickLeaveActSave_btn() {

		ebtn_Leave_Act_Save = driver.findElement(By.xpath(LeaveListPageProp.getbtnLeaveActSave()));
		ebtn_Leave_Act_Save.sendKeys(Keys.RETURN);

	}

	// get the current status of leave
	public static void getLeaveCurStatus_lbl() {

		elbl_Leave_Cur_Status = driver.findElement(By.xpath(LeaveListPageProp.getlblLeaveCurSts()));
		System.out.println(elbl_Leave_Cur_Status.getText());

	}
	
}
