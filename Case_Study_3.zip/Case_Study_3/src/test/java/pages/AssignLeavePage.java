package pages;

import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.testng.Assert;

import properties.AssignLeavePageProp;

public class AssignLeavePage {

	// Create object of WebDriver interface
	static WebDriver driver = null;

	static WebElement elbl_Assign_Leave;
	static WebElement etxt_Employee_Name;
	static WebElement edpDown_Leave_type;
	static WebElement elnk_View_LeaveBalance;
	static WebElement elbl_LeaveBalance;
	static WebElement ebtn_Balance_Ok;
	static WebElement edtPicker_From;
	static WebElement edtPicker_To;
	static WebElement edpDown_Duration1;
	// WebElement edpDown_Duration2;
	static WebElement etxtArea_Comment;
	static WebElement ebtn_Assign_Leave;
	static WebElement ebtn_Confirm_Leave;
	static WebElement elbl_Confirm_Msg;
	static WebElement elnk_Leave_List;

	// Create constructor of a class
	public AssignLeavePage(WebDriver webDriver) {
		driver = webDriver;
	}

	// Check whether Assign Leave label is displayed
	public static void checkAssignLeave_Lbl() {

		// Wait until page load
		@SuppressWarnings("deprecation")
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(15, TimeUnit.SECONDS)
				.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(AssignLeavePageProp.getlblAssignLeave())));

		elbl_Assign_Leave = driver.findElement(By.xpath(AssignLeavePageProp.getlblAssignLeave()));
		Assert.assertTrue(!elbl_Assign_Leave.isDisplayed());
		Assert.assertEquals(elbl_Assign_Leave.getText(), "Assign Leave");
		System.out.println("Assign Leave Page successfuly loaded");

	}

	// Send the employee name for the text box
	public static void setEmployeeName_txt(String empName) {

		etxt_Employee_Name = driver.findElement(By.id(AssignLeavePageProp.gettxtEmpName()));
		etxt_Employee_Name.clear();
		etxt_Employee_Name.sendKeys(empName);
	}

	// Select Assign Leave Type dropDown
	public static void selectLeaveType_dpDown(int value) {

		edpDown_Leave_type = driver.findElement(By.id(AssignLeavePageProp.getdpDownLeaveType()));
		Select leaveType = new Select(edpDown_Leave_type);
		leaveType.selectByIndex(value);
		// System.out.println(edpDown_Leave_type.getText());
	}

	// Click on leave balance details Link
	public static void clickLeaveBalance_lnk() {

		// Wait until leave balance link loaded
		@SuppressWarnings("deprecation")
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(30, TimeUnit.SECONDS)
				.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class);
		wait.until(ExpectedConditions.elementToBeClickable(By.id(AssignLeavePageProp.getlnkLeaveBalance())));

		elnk_View_LeaveBalance = driver.findElement(By.id(AssignLeavePageProp.getlnkLeaveBalance()));
		Assert.assertTrue(elnk_View_LeaveBalance.isEnabled());
		Assert.assertTrue(elnk_View_LeaveBalance.isDisplayed());
		elnk_View_LeaveBalance.click();
	}

	// Find the amount of leave balance
	public static void viewLeaveBalance_lbl() {

		elbl_LeaveBalance = driver.findElement(By.xpath(AssignLeavePageProp.getlblAssignLeave()));
		System.out.println("Available Leave balance is: " + elbl_LeaveBalance.getText().toString());
	}

	// Click on leave balance details okay button
	public static void clickLeaveBalance_btn() {
		
		//wait until leave balance details window loaded
//		@SuppressWarnings("deprecation")
//		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(30, TimeUnit.SECONDS)
//				.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class);
//		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(AssignLeavePageProp.getbtnBalanceDetail())));

		ebtn_Balance_Ok = driver.findElement(By.xpath(AssignLeavePageProp.getbtnBalanceDetail()));
		ebtn_Balance_Ok.click();
	}

	// Set the leave start date
	public static void setFromDate_dtPicker(String fromDate) {

		edtPicker_From = driver.findElement(By.xpath(AssignLeavePageProp.getdtPickerFromDt()));
		edtPicker_From.clear();
		edtPicker_From.sendKeys(fromDate);
		edtPicker_From.click();
	}

	// Set the leave end date
	public static void setToDate_dtPicker(String toDate) {

		edtPicker_To = driver.findElement(By.xpath(AssignLeavePageProp.getdtPickerToDt()));
		edtPicker_To.clear();
		edtPicker_To.sendKeys(toDate);
		edtPicker_To.click();
	}

	// Select the duration type
	public static void selectDuration_dpDown() {

		edpDown_Duration1 = driver.findElement(By.xpath(AssignLeavePageProp.getdpDownDuration()));
		Select duType = new Select(edpDown_Duration1);
		duType.selectByIndex(0);
	}

	// set the comment for the leave
	public static void setComment_textArea(String comment) {

		etxtArea_Comment = driver.findElement(By.xpath(AssignLeavePageProp.gettxtAreaComments()));
		etxtArea_Comment.clear();
		etxtArea_Comment.sendKeys(comment);
	}

	// Submit the assign leave form
	public static void clickAssignLeave_btn() {

		ebtn_Assign_Leave = driver.findElement(By.xpath(AssignLeavePageProp.getbtnAssignLeave()));
		ebtn_Assign_Leave.submit();
	}

	// Confirm the assign leave form
	public static void clickConfirmLeave_btn() {

		ebtn_Confirm_Leave = driver.findElement(By.xpath(AssignLeavePageProp.getbtnConfirmLeave()));
		ebtn_Confirm_Leave.click();
	}

	// Get the Assign Leave Confirmation message
	public static void getLeaveConfirmMsg() {

		elbl_Confirm_Msg = driver.findElement(By.xpath(AssignLeavePageProp.getlblLeavemsg()));
		System.out.println("Leave Confirmation Message is: " + elbl_Confirm_Msg.getText());
	}

	// Click the menu button leave list
	public static void gotoLeaveListPage() {

		elnk_Leave_List = driver.findElement(By.xpath(AssignLeavePageProp.getlnkLeaveList()));
		elnk_Leave_List.click();
		
	}

}
