package properties;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

public class LeaveListPageProp {

	// Create object of the class properties
	static Properties prop = new Properties();

	public static String getdtPickerFromDt() {
		String dtPicker_From_dt = null;
		try {

			InputStream input = new FileInputStream(
					System.getProperty("user.dir") + "/src/test/resources/Config.properties");

			// load the property file
			prop.load(input);
			// get the property of Date Picker From Date
			dtPicker_From_dt = prop.getProperty("dtPicker_From_dt");

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return dtPicker_From_dt;

	}

	public static String getdtPickerToDt() {
		String dtPicker_To_dt = null;
		try {

			InputStream input = new FileInputStream(
					System.getProperty("user.dir") + "/src/test/resources/Config.properties");

			// load the property file
			prop.load(input);
			// get the property of Date Picker To Date
			dtPicker_To_dt = prop.getProperty("dtPicker_To_dt");

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return dtPicker_To_dt;

	}

	public static String getchkBxAllLeaveSts() {
		String chkBx_Leave_Sts_All = null;
		try {

			InputStream input = new FileInputStream(
					System.getProperty("user.dir") + "/src/test/resources/Config.properties");

			// load the property file
			prop.load(input);
			// get the property of All Leave Status check box
			chkBx_Leave_Sts_All = prop.getProperty("chkBx_Leave_Sts_All");

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return chkBx_Leave_Sts_All;

	}

	public static String getchkBxRejLeaveSts() {
		String chkBx_Leave_Sts_Rej = null;
		try {

			InputStream input = new FileInputStream(
					System.getProperty("user.dir") + "/src/test/resources/Config.properties");

			// load the property file
			prop.load(input);
			// get the property of Reject Leave Status check box
			chkBx_Leave_Sts_Rej = prop.getProperty("chkBx_Leave_Sts_Rej");

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return chkBx_Leave_Sts_Rej;

	}

	public static String getchkBxCnclLeaveSts() {
		String chkBx_Leave_Sts_Cncl = null;
		try {

			InputStream input = new FileInputStream(
					System.getProperty("user.dir") + "/src/test/resources/Config.properties");

			// load the property file
			prop.load(input);
			// get the property of Cancel Leave Status check box
			chkBx_Leave_Sts_Cncl = prop.getProperty("chkBx_Leave_Sts_Cncl");

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return chkBx_Leave_Sts_Cncl;

	}

	public static String getchkBxPAprvLeaveSts() {
		String chkBx_Leave_Sts_PAprv = null;
		try {

			InputStream input = new FileInputStream(
					System.getProperty("user.dir") + "/src/test/resources/Config.properties");

			// load the property file
			prop.load(input);
			// get the property of Pending Approval Leave Status check box
			chkBx_Leave_Sts_PAprv = prop.getProperty("chkBx_Leave_Sts_PAprv");

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return chkBx_Leave_Sts_PAprv;

	}

	public static String getchkBxSchdlLeaveSts() {
		String chkBx_Leave_Sts_Schdl = null;
		try {

			InputStream input = new FileInputStream(
					System.getProperty("user.dir") + "/src/test/resources/Config.properties");

			// load the property file
			prop.load(input);
			// get the property of Scheduled Leave Status check box
			chkBx_Leave_Sts_Schdl = prop.getProperty("chkBx_Leave_Sts_Schdl");

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return chkBx_Leave_Sts_Schdl;

	}

	public static String getchkBxTknLeaveSts() {
		String chkBx_Leave_Sts_Tkn = null;
		try {

			InputStream input = new FileInputStream(
					System.getProperty("user.dir") + "/src/test/resources/Config.properties");

			// load the property file
			prop.load(input);
			// get the property of Taken Leave Status check box
			chkBx_Leave_Sts_Tkn = prop.getProperty("chkBx_Leave_Sts_Tkn");

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return chkBx_Leave_Sts_Tkn;

	}

	public static String gettxtEmpName() {
		String txt_Emp_Name = null;
		try {

			InputStream input = new FileInputStream(
					System.getProperty("user.dir") + "/src/test/resources/Config.properties");

			// load the property file
			prop.load(input);
			// get the property of employee name text box
			txt_Emp_Name = prop.getProperty("txt_Emp_Name");

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return txt_Emp_Name;

	}
	
	public static String getdpDownSubUnit() {
		String dpDown_Sub_Unit = null;
		try {

			InputStream input = new FileInputStream(
					System.getProperty("user.dir") + "/src/test/resources/Config.properties");

			// load the property file
			prop.load(input);
			// get the property of sub unit dropDown list
			dpDown_Sub_Unit = prop.getProperty("dpDown_Sub_Unit");

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return dpDown_Sub_Unit;

	}
	
	public static String getchkBxPastEmp() {
		String chkBox_Past_Emp = null;
		try {

			InputStream input = new FileInputStream(
					System.getProperty("user.dir") + "/src/test/resources/Config.properties");

			// load the property file
			prop.load(input);
			// get the property of past employee check box
			chkBox_Past_Emp = prop.getProperty("chkBox_Past_Emp");

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return chkBox_Past_Emp;

	}
	
	public static String getbtnSearchLeave() {
		String btn_Leave_Search = null;
		try {

			InputStream input = new FileInputStream(
					System.getProperty("user.dir") + "/src/test/resources/Config.properties");

			// load the property file
			prop.load(input);
			// get the property of search button
			btn_Leave_Search = prop.getProperty("btn_Leave_Search");

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return btn_Leave_Search;

	}
	
	public static String getlblNoSearchRecords() {
		String lbl_No_Record = null;
		try {

			InputStream input = new FileInputStream(
					System.getProperty("user.dir") + "/src/test/resources/Config.properties");

			// load the property file
			prop.load(input);
			// get the property of label No Records Found
			lbl_No_Record = prop.getProperty("lbl_No_Record");

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return lbl_No_Record;

	}
	
	public static String getdpDownLeaveAction() {
		String dpDown_Leave_Action = null;
		try {

			InputStream input = new FileInputStream(
					System.getProperty("user.dir") + "/src/test/resources/Config.properties");

			// load the property file
			prop.load(input);
			// get the property of leave action drop down list
			dpDown_Leave_Action = prop.getProperty("dpDown_Leave_Action");

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return dpDown_Leave_Action;

	}

	public static String getbtnLeaveActSave() {
		String btn_Leave_Act_Save = null;
		try {

			InputStream input = new FileInputStream(
					System.getProperty("user.dir") + "/src/test/resources/Config.properties");

			// load the property file
			prop.load(input);
			// get the property of leave action saving button
			btn_Leave_Act_Save = prop.getProperty("btn_Leave_Act_Save");

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return btn_Leave_Act_Save;

	}
	
	public static String getlblLeaveCurSts() {
		String lbl_Leave_Cur_Status = null;
		try {

			InputStream input = new FileInputStream(
					System.getProperty("user.dir") + "/src/test/resources/Config.properties");

			// load the property file
			prop.load(input);
			// get the property of leave current status label
			lbl_Leave_Cur_Status = prop.getProperty("lbl_Leave_Cur_Status");

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return lbl_Leave_Cur_Status;

	}
}
