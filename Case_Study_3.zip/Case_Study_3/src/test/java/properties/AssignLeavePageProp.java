package properties;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

public class AssignLeavePageProp {

	// Create object of the class properties
	static Properties prop = new Properties();

	public static String getlblAssignLeave() {
		String lbl_Assign_Leave = null;
		try {

			InputStream input = new FileInputStream(
					System.getProperty("user.dir") + "/src/test/resources/Config.properties");

			// load the property file
			prop.load(input);
			// get the property of Employee Name Text Box
			lbl_Assign_Leave = prop.getProperty("lbl_Assign_Leave");

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return lbl_Assign_Leave;

	}

	public static String gettxtEmpName() {
		String txt_Employee_Name = null;
		try {

			InputStream input = new FileInputStream(
					System.getProperty("user.dir") + "/src/test/resources/Config.properties");

			// load the property file
			prop.load(input);
			// get the property of Employee Name Text Box
			txt_Employee_Name = prop.getProperty("txt_Employee_Name");

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return txt_Employee_Name;

	}

	public static String getdpDownLeaveType() {
		String dpDown_Leave_type = null;
		try {

			InputStream input = new FileInputStream(
					System.getProperty("user.dir") + "/src/test/resources/Config.properties");

			// load the property file
			prop.load(input);
			// get the property of Leave Type DropDownBox
			dpDown_Leave_type = prop.getProperty("dpDown_Leave_type");

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return dpDown_Leave_type;

	}

	public static String getlblLeaveBalance() {
		String lbl_LeaveBalance = null;
		try {

			InputStream input = new FileInputStream(
					System.getProperty("user.dir") + "/src/test/resources/Config.properties");

			// load the property file
			prop.load(input);
			// get the property of leave balance label
			lbl_LeaveBalance = prop.getProperty("lbl_LeaveBalance");

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return lbl_LeaveBalance;

	}

	public static String getlnkLeaveBalance() {
		String lnk_View_LeaveBalance = null;
		try {

			InputStream input = new FileInputStream(
					System.getProperty("user.dir") + "/src/test/resources/Config.properties");

			// load the property file
			prop.load(input);
			// get the property of view leave balance link
			lnk_View_LeaveBalance = prop.getProperty("lnk_View_LeaveBalance");

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return lnk_View_LeaveBalance;

	}

	public static String getbtnBalanceDetail() {
		String btn_Balance_Ok = null;
		try {

			InputStream input = new FileInputStream(
					System.getProperty("user.dir") + "/src/test/resources/Config.properties");

			// load the property file
			prop.load(input);
			// get the property of leave balance window okay button
			btn_Balance_Ok = prop.getProperty("btn_Balance_Ok");

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return btn_Balance_Ok;

	}

	public static String getdtPickerFromDt() {
		String dtPicker_From = null;
		try {

			InputStream input = new FileInputStream(
					System.getProperty("user.dir") + "/src/test/resources/Config.properties");

			// load the property file
			prop.load(input);
			// get the property of date picker of From Date
			dtPicker_From = prop.getProperty("dtPicker_From");

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return dtPicker_From;

	}

	public static String getdpDownDuration() {
		String dpDown_Duration1 = null;
		try {

			InputStream input = new FileInputStream(
					System.getProperty("user.dir") + "/src/test/resources/Config.properties");

			// load the property file
			prop.load(input);
			// get the property of duration1 dropDownBox
			dpDown_Duration1 = prop.getProperty("dpDown_Duration1");

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return dpDown_Duration1;

	}

	public static String getdtPickerToDt() {
		String dtPicker_To = null;
		try {

			InputStream input = new FileInputStream(
					System.getProperty("user.dir") + "/src/test/resources/Config.properties");

			// load the property file
			prop.load(input);
			// get the property of date picker of To Date
			dtPicker_To = prop.getProperty("dtPicker_To");

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return dtPicker_To;

	}

	public static String gettxtAreaComments() {
		String txtArea_Comment = null;
		try {

			InputStream input = new FileInputStream(
					System.getProperty("user.dir") + "/src/test/resources/Config.properties");

			// load the property file
			prop.load(input);
			// get the property of Comments text Area
			txtArea_Comment = prop.getProperty("txtArea_Comment");

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return txtArea_Comment;

	}

	public static String getbtnAssignLeave() {
		String btn_Assign_Leave = null;
		try {

			InputStream input = new FileInputStream(
					System.getProperty("user.dir") + "/src/test/resources/Config.properties");

			// load the property file
			prop.load(input);
			// get the property of Leave Assign button
			btn_Assign_Leave = prop.getProperty("btn_Assign_Leave");

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return btn_Assign_Leave;

	}
	
	public static String getbtnConfirmLeave() {
		String btn_Confirm_Leave = null;
		try {

			InputStream input = new FileInputStream(
					System.getProperty("user.dir") + "/src/test/resources/Config.properties");

			// load the property file
			prop.load(input);
			// get the property of Confirm Leave button
			btn_Confirm_Leave = prop.getProperty("btn_Confirm_Leave");

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return btn_Confirm_Leave;

	}
	
	public static String getlblLeavemsg() {
		String lbl_Leave_Msg = null;
		try {

			InputStream input = new FileInputStream(
					System.getProperty("user.dir") + "/src/test/resources/Config.properties");

			// load the property file
			prop.load(input);
			// get the property of Confirm Leave button
			lbl_Leave_Msg = prop.getProperty("lbl_Leave_Msg");

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return lbl_Leave_Msg;

	}
	
	public static String getlnkLeaveList() {
		String lnk_Leave_List = null;
		try {

			InputStream input = new FileInputStream(
					System.getProperty("user.dir") + "/src/test/resources/Config.properties");

			// load the property file
			prop.load(input);
			// get the property of Leave list menu
			lnk_Leave_List = prop.getProperty("lnk_Leave_List");

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return lnk_Leave_List;

	}


}
