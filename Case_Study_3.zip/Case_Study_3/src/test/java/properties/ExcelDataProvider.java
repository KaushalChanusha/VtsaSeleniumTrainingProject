package properties;

import java.util.ArrayList;

public class ExcelDataProvider {

	public static String emp_Name = null;
	public static String leaveType = null;
	public static String fromDate = null;
	public static String toDate = null;
	public static String duration = null;
	public static String comment = null;
	public static int leaveindex = 0;
	public static String schDateFrom = null;
	public static String schDateTo = null;
	public static String leaveSts = null;
	public static String schEmpName = null;
	public static String subUnit = null;
	public static int subUnitIndex = 0;
	public static String passEmp = null;

	static int rowCount = 0;
	static int colCount = 0;

	// get the test data related to LoginPage
	public static Object[][] readLoginPageTestData(String excelPath, String sheetName) {

		ExcelSheet excel = new ExcelSheet(excelPath, sheetName);

		rowCount = excel.getRowCount();
		colCount = excel.getColCount();

		Object data[][] = new Object[rowCount - 1][colCount];

		for (int i = 1; i < rowCount; i++) {

			for (int j = 0; j < colCount; j++) {

				String cellData = excel.getCellDataStrings(i, j);
				// System.out.println(cellData);
				data[i - 1][j] = cellData;
			}
		}
		return data;

	}

	public static void getAssignLeavePageTestData(String excelPath, String sheetName) {

		ExcelSheet exe = new ExcelSheet(excelPath, sheetName);

		rowCount = exe.getRowCount();
		colCount = exe.getColCount();
		ArrayList<String> al = new ArrayList<String>();

		for (int i = 1; i < rowCount; i++) {

			for (int j = 0; j < colCount; j++) {

				String cellData = exe.getCellDataStrings(i, j);
				al.add(cellData);
			}
			emp_Name = al.get(0);
			leaveType = al.get(1);
			fromDate = al.get(2);
			toDate = al.get(3);
			duration = al.get(4);
			comment = al.get(5);

			if (leaveType.equalsIgnoreCase("FMLA US")) {
				leaveindex = 1;
			} else if (leaveType.equalsIgnoreCase("Maternity US")) {
				leaveindex = 2;
			} else if (leaveType.equalsIgnoreCase("Paternity US")) {
				leaveindex = 3;
			} else if (leaveType.equalsIgnoreCase("Vacation US")) {
				leaveindex = 4;
			}
			// System.out.println(al.get(0));
			// System.out.println(leaveindex);
			// al.clear();
		}
	}

	public static void getAssignLeavePageTestData2(String excelPath, String sheetName) {

		ExcelSheet exe = new ExcelSheet(excelPath, sheetName);

		rowCount = exe.getRowCount();
		colCount = exe.getColCount();
		ArrayList<String> al = new ArrayList<String>();

		for (int i = 2; i < rowCount; i++) {

			for (int j = 0; j < colCount; j++) {

				String cellData = exe.getCellDataStrings(i, j);
				al.add(cellData);
			}
			emp_Name = al.get(0);
			leaveType = al.get(1);
			fromDate = al.get(2);
			toDate = al.get(3);
			duration = al.get(4);
			comment = al.get(5);

			if (leaveType.equalsIgnoreCase("FMLA US")) {
				leaveindex = 1;
			} else if (leaveType.equalsIgnoreCase("Maternity US")) {
				leaveindex = 2;
			} else if (leaveType.equalsIgnoreCase("Paternity US")) {
				leaveindex = 3;
			} else if (leaveType.equalsIgnoreCase("Vacation US")) {
				leaveindex = 4;
			}
			// System.out.println(al.get(0));
			// System.out.println(leaveindex);
			// al.clear();
		}

	}

	public static void getLeaveListPageTestData(String excelPath, String sheetName) {

		ExcelSheet exe = new ExcelSheet(excelPath, sheetName);

		rowCount = exe.getRowCount();
		colCount = exe.getColCount();
		ArrayList<String> al = new ArrayList<String>();

		for (int i = 1; i < rowCount; i++) {

			for (int j = 0; j < colCount; j++) {

				String cellData = exe.getCellDataStrings(i, j);
				al.add(cellData);
			}
			schDateFrom = al.get(0);
			schDateTo = al.get(1);
			leaveSts = al.get(2);
			schEmpName = al.get(3);
			subUnit = al.get(4);
			passEmp = al.get(5);

			if (subUnit.equalsIgnoreCase("All")) {
				subUnitIndex = 0;
			} else if (subUnit.equalsIgnoreCase("Sales")) {
				subUnitIndex = 1;
			} else if (subUnit.equalsIgnoreCase("Administration")) {
				subUnitIndex = 2;
			} else if (subUnit.equalsIgnoreCase("IT")) {
				subUnitIndex = 3;
			} else if (subUnit.equalsIgnoreCase("Finance")) {
				subUnitIndex = 4;
			}
			// System.out.println(al.get(3));
			// System.out.println(subUnitIndex);
			// al.clear();
		}
	}

	// public static void main(String[] args) {
	// getLeaveListPageTestData("/src/test/resources/testdata.xlsx",
	// "leaveListSheet");
	// }

}
