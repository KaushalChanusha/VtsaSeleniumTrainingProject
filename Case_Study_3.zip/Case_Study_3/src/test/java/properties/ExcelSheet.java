package properties;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelSheet {

	XSSFWorkbook workbook;
	static XSSFSheet sheet;

//	public static void main(String[] args) {
//		new ExcelSheet("/src/test/resources/testdata.xlsx", "loginSheet");
//		System.out.println(getRowCount() + getColCount()+getCellDataStrings(1, 1));
//	}

	@SuppressWarnings("deprecation")
	public ExcelSheet(String excelPath, String sheetName) {

		try {
			// Create reference for WorkBook
			workbook = new XSSFWorkbook(System.getProperty("user.dir") + excelPath);
			// Create reference for WorkSheet
			sheet = workbook.getSheet(sheetName);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// get the No of rows
	public static int getRowCount() {
		int rowCount = 0;
		try {
			rowCount = sheet.getPhysicalNumberOfRows();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return rowCount;

	}

	// get the No of columns
	public static int getColCount() {
		int colCount = 0;
		try {
			colCount = sheet.getRow(0).getPhysicalNumberOfCells();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return colCount;

	}

	// read data Strings
	public static String getCellDataStrings(int rowNum, int colNum) {
		String cellData = null;
		try {
			cellData = sheet.getRow(rowNum).getCell(colNum).getStringCellValue();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return cellData;

	}

}
