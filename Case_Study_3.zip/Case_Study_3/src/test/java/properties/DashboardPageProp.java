package properties;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

public class DashboardPageProp {

	// Create object of the class properties
	static Properties prop = new Properties();

	public static String getlblDashboard() {
		String lbl_Dashboard=null;
		try {

			InputStream input = new FileInputStream(
					System.getProperty("user.dir") + "/src/test/resources/Config.properties");

			// load the property file
			prop.load(input);

			// get the property of DashBoard Label
			lbl_Dashboard = prop.getProperty("lbl_Dashboard");

		} catch (Exception e) {
			e.printStackTrace();
		}
		return lbl_Dashboard;

	}

	public static String getlnkAssignLeave() {
		String link_Assign_Leave=null;
		try {

			InputStream input = new FileInputStream(
					System.getProperty("user.dir") + "/src/test/resources/Config.properties");

			// load the property file
			prop.load(input);

			// get the property of Assign Leave link
			link_Assign_Leave = prop.getProperty("link_Assign_Leave");
			

		} catch (Exception e) {
			e.printStackTrace();
		}
		return link_Assign_Leave;
	}

	
}
