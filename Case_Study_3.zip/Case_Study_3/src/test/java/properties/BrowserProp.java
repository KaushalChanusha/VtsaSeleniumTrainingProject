package properties;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

import test.AssignLeavePageTest;
import test.LeaveListPageTest;
import test.LoginPageTest;
import test.WebDriverSetUp;

public class BrowserProp {

	// Create object of the class properties
	static Properties prop = new Properties();

	public static void getBrowserProperties() {

		try {

			InputStream input = new FileInputStream(
					System.getProperty("user.dir") + "/src/test/resources/Config.properties");

			// load the property file
			prop.load(input);

			// get the property of BrowserType
			WebDriverSetUp.browserName = prop.getProperty("BrowserName");
			// get the path of ChromeDriver
			WebDriverSetUp.chromeDriverPath = prop.getProperty("chromeDriverPath");
			// get the path of GeckoDriver
			WebDriverSetUp.geckoDriverPath = prop.getProperty("geckoDriverPath");
			// get the path of IEDriver
			WebDriverSetUp.ieDriverPath = prop.getProperty("ieDriverPath");
			// System.out.println( prop.getProperty("chromeDriverPath"));
			// get the URL
			LoginPageTest.webUrl = prop.getProperty("webUrl");
			AssignLeavePageTest.webUrl = prop.getProperty("webUrl");
			LeaveListPageTest.webUrl = prop.getProperty("webUrl");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}

}
