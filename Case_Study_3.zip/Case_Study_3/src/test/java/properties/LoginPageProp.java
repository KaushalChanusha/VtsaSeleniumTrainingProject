package properties;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

public class LoginPageProp {

	// Create object of the class properties
	static Properties prop = new Properties();

	public static String getlblLoginPage() {
		String lbl_Login = null;
		try {
			// Create object of class InputStream
			InputStream input = new FileInputStream(
					System.getProperty("user.dir") + "/src/test/resources/Config.properties");

			// load the property file
			prop.load(input);

			// get property of login page label
			lbl_Login = prop.getProperty("lbl_Login");

		} catch (Exception e) {
			// TODO: handle exception
			e.getMessage();
			e.printStackTrace();
		}
		return lbl_Login;

	}

	public static String gettxtUserName() {
		String txt_UserName = null;
		try {
			// Create object of class InputStream
			InputStream input = new FileInputStream(
					System.getProperty("user.dir") + "/src/test/resources/Config.properties");

			// load the property file
			prop.load(input);

			// get property of UserName textBox
			txt_UserName = prop.getProperty("txt_UserName");

		} catch (Exception e) {
			// TODO: handle exception
			e.getMessage();
			e.printStackTrace();
		}
		return txt_UserName;

	}

	public static String gettxtPassword() {
		String txtPassword = null;
		try {
			// Create object of class InputStream
			InputStream input = new FileInputStream(
					System.getProperty("user.dir") + "/src/test/resources/Config.properties");

			// load the property file
			prop.load(input);

			// get property of PassWord TextBox
			txtPassword = prop.getProperty("txt_Password");

		} catch (Exception e) {
			// TODO: handle exception
			e.getMessage();
			e.printStackTrace();
		}
		return txtPassword;

	}

	public static String getbtnLogin() {
		String btnLogin = null;
		try {
			// Create object of class InputStream
			InputStream input = new FileInputStream(
					System.getProperty("user.dir") + "/src/test/resources/Config.properties");

			// load the property file
			prop.load(input);

			// get property of Login button
			btnLogin = prop.getProperty("btn_Login");

		} catch (Exception e) {
			// TODO: handle exception
			e.getMessage();
			e.printStackTrace();
		}
		return btnLogin;

	}
}
